document.addEventListener('DOMContentLoaded', function() {
    var gateway = `ws://${window.location.hostname}/ws`;
    // Create a WebSocket connection
    var socket = new WebSocket(gateway); // Replace 'wss://example.com' with your WebSocket server URL
    const maxRetries = 5; // Maximum number of retry attempts
    let currentRetry = 0; // Current retry attempt
    
    connectWebsocket();
    function connectWebsocket(){
    // Handle WebSocket connection opened event
    socket.onopen = function(event) {
        console.log('WebSocket connection opened');
        create_sliders_handlers();
        create_settings_sliders_handlers();
        add_switches_handlers();
    };

   
    socket.onmessage = function(event) {
        console.log("received ",event.data);  
        };

    socket.onclose = function(event) {
    if (currentRetry < maxRetries) {
      currentRetry++;
      console.log(`[SLIEDERS}WebSocket connection closed. Retrying in 2 seconds... (Attempt ${currentRetry}/${maxRetries})`);
      setTimeout(connectWebSocket, 1000); // Retry after 2 seconds
    } else {
      console.error('WebSocket connection failed after maximum retry attempts.');
    }
    };
    }
   
    function create_sliders_handlers(){
        for(let i = 1; i < 10; i++){
          let macroid = 'macro_th'+i;
          let microid = 'micro_th'+i;
          let macro_slider = document.getElementById(macroid);
          let micro_slider = document.getElementById(microid); 
          
          macro_slider.addEventListener('input', function() {
            send_json_over_ws(macro_slider);
          });
  
          micro_slider.addEventListener('input', function() {
            send_json_over_ws(micro_slider);
          });
        }     
    }

    function create_settings_sliders_handlers(){
      let max_macro_range = document.getElementById("max_macro_range"); 
      max_macro_range.addEventListener('input', function() {      
        send_json_over_ws(max_macro_range);
      });

      let max_micro_range = document.getElementById("max_micro_range");             
      max_micro_range.addEventListener('input', function() {      
        send_json_over_ws(max_micro_range);
      });

      let Timeout = document.getElementById("Timeout");         
      Timeout.addEventListener('input', function() {      
        send_json_over_ws(Timeout);
      });
      
      let pir_sensitivity = document.getElementById("pir_sensitivity");      
      pir_sensitivity.addEventListener('input', function() {      
        send_json_over_ws(pir_sensitivity);
      });  
    }

    function send_json_over_ws(slider){
      const value = slider.value;
      const name = slider.id;
      const data = { value, name }; 
      console.log('Slider Context:', data);
      socket.send(JSON.stringify(data));
    }
    function add_switches_handlers(){
    var sw0 = document.getElementById('switch-0');
    // Event listener for checkbox change
      sw0.addEventListener('change', function() {
        let name = "CalSense";
        let value = sw0.checked? "1" : "0";
        const SWdata = {name, value};
        console.log(JSON.stringify( SWdata));
        socket.send(JSON.stringify( SWdata));
      });
    
      var sw1 = document.getElementById('switch-1'); 
      sw1.addEventListener('change', function() {
        let name = "BedSense";
        let value = sw1.checked? "1" : "0";
        const SWdata = {name, value};
        console.log(JSON.stringify( SWdata));
        socket.send(JSON.stringify( SWdata));
      });
    }
});
