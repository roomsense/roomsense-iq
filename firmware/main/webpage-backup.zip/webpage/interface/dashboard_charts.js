document.addEventListener('DOMContentLoaded', function() {
  var lastUpdateTime = 0;
  var avg_time = 0;
  var itr = 0;
  var waveform1= {}, waveform2= {}, waveform3= {}, waveform4= {}, waveform5= {};
  
  let range = [0, 100];
  let labels_data =  [0, 75, 150, 225, 300, 375, 450, 525, 600];
  Create_Waveform_Chart(waveform1,"waveform-1", "Macro Movement", range,true,  true, labels_data);
  Create_Waveform_Chart(waveform2,"waveform-2", "Micro Movement", range,true, true, labels_data);
  
  range = [0, 100];

  labels_data = [];
  Create_Waveform_Chart(waveform3,"waveform-3" ,"Temprature",     range,false,  true, labels_data);
  Create_Waveform_Chart(waveform4,"waveform-4" ,"Humidity",       range,false, true, labels_data);
  
  range = [0, 4100];
  Create_Waveform_Chart(waveform5,"waveform-5" ,"Light Density",  range,false, true, labels_data);
  start_websocket_client(50);

let os_last_state = 0xff;
function update_occupation_status(state) {  
    if(os_last_state != state ){
      console.log("Updating occ state",state);
      var occ_state = document.getElementById("occ_state");
      const statusElement = document.querySelector('.status');
      statusElement.textContent = state;
      if (state == 'Unoccupied') occ_state.src = "home_unoccupid.png";
      else if (state == 'Occupied') occ_state.src = "home_occupid.png";
      os_last_state = state;
    }
}

let md_last_state;
function update_pir_motion_detection_status(state) {
  if(md_last_state != state){
    console.log("Updating motion state :  ", state);
    var motion_status = document.getElementById("motion_status");
    if(state == 'true')motion_status.src = "motion_true.png";
    else if(state == 'false')motion_status.src = "motion_false.png";
    md_last_state = state;
  }
}
const maxRetries = 5; // Maximum number of retry attempts
let currentRetry = 0; // Current retry attempt

function start_websocket_client(poll_interval){
    //var gateway ="ws://localhost:8080"
    var gateway = `ws://${window.location.hostname}/ws`;
    // Create a WebSocket connection
    var socket = new WebSocket(gateway); // Replace 'wss://example.com' with your WebSocket server URL
  
    // Handle WebSocket connection opened event
    socket.onopen = function(event) {
      console.log('WebSocket connection opened');
      setInterval(function() {
        var message = 'data_request';
        socket.send(message);
        //console.log('Sent:', message);
    }, poll_interval);
    };
    
    socket.onclose = function(event) {
    if (currentRetry < maxRetries) {
      currentRetry++;
      console.log(`WebSocket connection closed. Retrying in 2 seconds... (Attempt ${currentRetry}/${maxRetries})`);
      setTimeout(start_websocket_client, 2000); // Retry after 2 seconds
    } else {
      console.error('WebSocket connection failed after maximum retry attempts.');
    }
  };
  
    // Handle WebSocket message received event
    socket.onmessage = function(event) {
      
    //console.log("received ",event.data);  
    var newData = JSON.parse(event.data);
    if(newData.macromovement[0] != "NULL"){
      let lbl = [0, 75, 150, 225, 300, 375, 450, 525, 600];
      update_charts(waveform1.chart,newData.macromovement, true, lbl);
      
    }
    if(newData.micromovement[0] != "NULL"){
      let lbl = [0, 75, 150, 225, 300, 375, 450, 525, 600];
      update_charts(waveform2.chart,newData.micromovement, true, lbl);
    }
    if(newData.temperature[0] != "NULL"){
      let lbl = [0, 75, 150, 225, 300, 375, 450, 525, 600];
      update_chart(waveform3.chart,newData.temperature, true, lbl);
    }
    if(newData.humidity[0] != "NULL"){
      let lbl = [0, 75, 150, 225, 300, 375, 450, 525, 600];
      update_chart(waveform4.chart,newData.humidity, true,lbl);
    }
    if(newData.light_density[0] != "NULL"){
      let lbl = [0, 75, 150, 225, 300, 375, 450, 525, 600];
      update_chart(waveform5.chart,newData.light_density, true,lbl);
    }

    if(newData.distance != "NULL"){
      document.querySelector('.distance').textContent = newData.distance;
    };


    if(newData.occ_status  != "NULL"){
      update_occupation_status(newData.occ_status);
    }

    if(newData.motion_status != "NULL"){
      update_pir_motion_detection_status(newData.motion_status);
    }
    };
  
  
    // Handle WebSocket connection error event
    socket.onerror = function(error) {
    console.error('WebSocket error:', error);
    };  
}



  
function update_chart(ctx, data, append_labels, labels_data) {
  if(append_labels){
    ctx.data.labels = labels_data;
  }
  for (var i = 0; i < data.length; i++) {
    ctx.data.datasets[0].data[i] = data[i];
  }
  // Update the chart
  ctx.update({
    duration: 14,     
    easing: 'linear', 
    preservation: true
  });

}

  
function update_charts(ctx, dataset, append_labels, labels_data) {
  if(append_labels){
    ctx.data.labels = labels_data;
  }
  for (var i = 0; i < 9; i++) {
    ctx.data.datasets[0].data[i] = dataset[i];
  }

  for (var i = 0; i <9; i++) {
    ctx.data.datasets[1].data[i] = dataset[i+9];
  }

  // Update the chart
  ctx.update({
    duration: 14,     
    easing: 'linear', 
    preservation: true
  });

}

function Create_Waveform_Chart(waveform_obj, elementid, chart_title_name, range, xaxis_display, yaxis_display, labels_data) {
  var ctx1 = document.getElementById(elementid).getContext('2d');

  waveform_obj.chart = new Chart(ctx1, {
    type: 'line',
    data: {
      labels: labels_data,
      datasets: [
        {
          data: [],
          borderWidth: 1,
          borderColor: 'orange',
          backgroundColor: 'rgba(0, 0, 0, 0)',
          pointRadius: 0,
          lineTension: 0.1,
          fill: false,
        },
        {
          data: [],
          borderWidth: 1,
          borderColor: '#03a9f4',
          backgroundColor: 'rgba(0, 0, 0, 0)',
          pointRadius: 0,
          lineTension: 0.1,
          fill: false,
        }
      ]
    },
    options: {
      layout: {
        padding: 40
      },
      width: 550,
      height: 350,
      responsive: false,
      backgroundColor: 'rgba(0, 0, 0, 1)',
      scales: {
        x: {
          type: 'category',
          offset: true,
          display: xaxis_display,
        },
        x2: {
          type: 'category',
          offset: true,
          display: false, // Set display to false to hide the x2-axis labels
        },
        y: {
          display: yaxis_display,
          grid: {
            color: 'rgba(255, 255, 255, 0.1)'
          },
          suggestedMin: range[0],
          suggestedMax: range[1]
        },

      },
      elements: {
        line: {
          backgroundColor: 'orange',
          borderColor: 'orange',
          tension: 0.3
        }
      },
      animation: {
        duration: 0
      },
      interaction: {
        mode: 'nearest',
        intersect: false
      },
      plugins: {
        title: {
          color: 'rgba(255, 255, 255, 1)',
          text: chart_title_name,
          display: true
        },
        legend: {
          display: false
        },
        streaming: {
          frameRate: 30,
          duration: 10000,
          delay: 0
        }
      }
    }
  });
}
});
